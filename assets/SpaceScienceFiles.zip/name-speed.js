// import { Globals } from "/js/globals.js";
import { Widget } from "/js/widgets/widgets.js";

export default class NameSpeed extends Widget {

    constructor(options = {}) {
        super(options);

        let sourceID = options.id != null ? options.id : "";
        this.layout = options.layout != null ? options.layout : "../widgets/name-speed.htm";
        // let tag = options.tag != null ? options.tag : "";

        this.Name = "Name-Speed: #" + sourceID;
        this.template = "";
        this.parentID = "#" + sourceID;
        this.Parent = document.getElementById(sourceID);

        // Get Layout
        GetContent(this.layout).then((data) => {
            this.template = data;
            SetHtml(this.parentID, this.template);
            this.Render();

            // Your JavaScript will go here
            input.MapInput("#speed-0", "AllStop");
            input.MapInput("#speed-burst", "SpeedBurst");

            input.MapInput("#maneuver-orbit", "OrbitMode");
            input.MapInput("#maneuver-cruise", "CruiseMode");
            
            widgets.Update();

            ge("speed-guage").addEventListener("pointerdown", (event) => {
                // TODO: MOVE TO Speed Bar Function

                var height = event.currentTarget.parentElement.offsetHeight;
                var section = parseInt(height / 18);
                var padOffset = section;
                var maxForward = section * 16;
                var zeroLevel = padOffset + maxForward;

                var location = GetEventCoords(event.target, event);
                var vert = (location.y / w_scale) - padOffset;

                var relSpeed = 0;

                relSpeed = (maxForward - vert) / maxForward;

                //var ps = (max - location.y) / max;
                var ts = parseFloat(relSpeed);

                if (thisvessel.Maneuver == "Departing") {
                    if (ts > (.25)) ts = (.25);
                    SendCMD("VESSEL-THROTTLE", ts);
                } else if (thisvessel.Maneuver == "FTL") {
                    SendCMD("VESSEL-THROTTLE", parseFloat(4 * ts));
                } else {
                    SendCMD("VESSEL-THROTTLE", ts);
                }

            });
            ge("speed-100")?.addEventListener("pointerdown", (e) => { SendCMD("VESSEL-THROTTLE", 1); });
            ge("speed-75")?.addEventListener("pointerdown", (e) => { SendCMD("VESSEL-THROTTLE", .75); });
            ge("speed-50")?.addEventListener("pointerdown", (e) => { SendCMD("VESSEL-THROTTLE", .5); });
            ge("speed-25")?.addEventListener("pointerdown", (e) => { SendCMD("VESSEL-THROTTLE", .25); });

            input.MapInput("#speed-reverse", "ToggleReverse");

            this.Render();

        });

        game.Subscribe("ready", (m) => {
            AcceptPacket("VESSEL-THROTTLE-DIRECTION");
        });

        game.Subscribe('vessel-throttle-direction', (m) => {
            this.throttleForward = m.value;
            this.Render();
        });

          game.Subscribe('reset', (m) => {
              // Clear
              try {
                  //SetHtml(parentID, "");
              } catch (err) {
                  console.log(err.message);
              }
          });

    }

    Render() {
        try {
            const thr = ge("speed-reverse");
            
            if (this.throttleForward) {
                RemoveClass(".throttle-button", "reverse");
                RemoveClass("#speed-reverse", "back-orange");
                RemoveClass("#speed-reverse", "blink");
            } else {
                AddClass(".throttle-button", "reverse");
                AddClass("#speed-reverse", "back-orange");
                AddClass("#speed-reverse", "blink");
            }
        } catch (err) {
            console.log("DuaneSpeed.Render: " + err.message);
        }
    }

}