// import { Globals } from "/js/globals.js";
import { Widget } from "/js/widgets/widgets.js";

export default class NameAttitude extends Widget {

    constructor(options = {}) {
        super(options);

        let sourceID = options.id != null ? options.id : "";
        this.layout = options.layout != null ? options.layout : "../widgets/name-attitude.htm";
        // let tag = options.tag != null ? options.tag : "";

        this.Name = "Name-Attitude: #" + sourceID; 
        this.template = "";
        this.parentID = "#" + sourceID;
        this.Parent = document.getElementById(sourceID);

        // Get Layout
        GetContent(this.layout).then((data) => {
            this.template = data;
            SetHtml(this.parentID, this.template);
            this.Render();

            // Your JavaScript will go here
            

        });

        //   game.Subscribe('reset', (m) => {
        //       // Clear
        //       try {
        //           //SetHtml(parentID, "");
        //       } catch (err) {
        //           console.log(err.message);
        //       }
        //   });

    }

    Render() {
        try {

        } catch (err) {
            console.log("NameAttitude.Render: " + err.message);
        }
    }

}